let arr = ['mom', 'dad', 'jug', 'sis', 'moon', 'jij', 'wow'];
(function(arr) {

    let c = [];
    
    for (let i = 0; i < arr.length; i++) {
    
    let strarr = arr[i]
    
    let revstr = strarr.toString("").split("").reverse().join("");
    
    if (strarr == revstr) {
    
    c.push(strarr);
    
    }
    
    }
    
    console.log(c);
    
    })(arr);