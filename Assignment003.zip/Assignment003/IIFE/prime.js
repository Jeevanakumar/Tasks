let a = [5,11, 9, 21, 67, 203, 2111];
(prime = function(a) {

    for (let j = 2; j <= a - 1; j++) {
    
    if (a % j == 0) {
    
    return false;
    
    }
    
    }
    
    return a > 1
    
    })();
    
    console.log(a.filter(prime))