let arr = ['mom', 'moon', 'dad', 'sis', 'wow', 'love'];

//anonymous function

let palin = function(arr) {

let c = [];

for (let i = 0; i < arr.length; i++) {

let strarr = arr[i]

//Using reverse() method to reverse the string

let revstr = strarr.toString("").split("").reverse( ).join("");

//comparing the 2 strings and adding the string to array using push if condition satisfies

if (strarr == revstr) {

c.push(strarr);

}

}

console.log(c);

}

palin(arr);