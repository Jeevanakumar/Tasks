x = function(str) {

  var sentence = str.toLowerCase().split(' ');
  
  for (let i = 0; i < sentence.length; i++) {
  
  sentence[i] = sentence[i][0].toUpperCase() + sentence[i].slice(1);
  
  }
  
  console.log(sentence.join(' '));
  
  return sentence;
  
  }
  
  x('Jeevana is fond of cats');