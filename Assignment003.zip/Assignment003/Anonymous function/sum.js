a = [5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70];

b = function() {

let sum = 0;

for (let i = 0; i < a.length; i++) {

sum = sum + a[i];

}

return sum;

}

console.log(b());