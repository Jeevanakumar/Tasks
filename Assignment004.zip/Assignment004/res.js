let myResume={
    "basics": {
      "name": "JEEVANA K",
      "email": "jeesha112@gmail.com",
      "degree": "B.E",
      "location": {
        "address": "35 GN Chetty Rd ShenoyNagar",
        "postalCode": 600030,
        "city": "Chennai",
        "state": "Tamilnadu",
        "country": "India"
      },
      "profiles": [
        {
          "github":"https://github.com/Jeevanakumar/Tasks.git"
        }
      ]
    },
        "education": [
      {
        "institution": "Dr.SACOE",
        "department": "CSE",
        "studyType": "fulltime",
        "batch start year": 2013,
        "batch end year": 2017,
        "gpa": 7.5,
      }
    ],
    "skills": [
      {
        "Programming": "python,javascript",
        "level": "beginner",
        "Frontend": "HTML,CSS",
        "Backend": "MongoDB,SQL",
        "Framework": "ReactJS",
      }
    ],
    "languages": [
      {
        "language": "Tamil,English",
      }
    ],
    "interests": [
      {
        "name": "MUA,Dance",
      }
    ]
  }
  console.log(myResume);